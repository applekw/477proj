<div>
   <h3>Welcome to the Help Pages</h3>
   The page selection is available on the left hand side of every page.<br><br>
   <h4><b>Pages:</b></h4>
   &nbsp <b>Home</b> - The home page.<br>
   <br>
   &nbsp <b>Submit Preferred Schedule</b> - This page currently has no function.<br>
   <br>
   &nbsp <b>Search Tutors</b> - Here you can search for Tutors by name or by Course. <b>NOTE:</b> If search gives you trouble, use Tutor Profiles to find a tutor.<br>
   &nbsp &nbsp - Searching by name only allows you to search by first name. Partial search will be added soon.<br>
   &nbsp &nbsp - Searching by Course does not currently work.<br>
   <br>
   &nbsp <b>Tutor Profiles</b> - This page gives you a list of all tutors. From here you can then select a tutor and view their profile.<br>
   <br>
   
   &nbsp <b>Help</b> - This is where you are now.
</div>