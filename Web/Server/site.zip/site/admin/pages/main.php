<div>
   <h3>Welcome to the Learning Center Web Application</h3>
   Please select a page to go to.
</div>