<?php
require_once("../tutor_controller.php");
require_once('../db_con.php');


phpinfo();



/*
	$mysqli = getDBCon();

	$result = get_tutors_by_name_and_course($mysqli,"ian","ECE130");
	var_dump($result);
		
		
		
/*
$course_array = array("CSSE371","CSSE374");

foreach($course_array as $course)
{

	$course_info = get_course_by_crn($mysqli, $course);
	var_dump($course_info);
	echo("<br /><br />");
	/*
	$course_add_result = add_course_for_tutor($TID,$course_info->CID);
	var_dump($course_add_result);
	echo("<br /><br />");
	
}*/
?>