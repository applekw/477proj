<div>
  <h3>Tutor Search</h3>
  <form method="get"
        action="index.php">
    <input type="hidden" name="page" value="tutor_search_results" />
    Search: <input type="text" name="search" /><br />
    Search Type:<br />
    Name: <input type="radio" name="type" value="name"
                 checked="checked" />
    Course: <input type="radio" name="type" value="course" />
    <br />
    <input type="submit" name="Submit" />
  </form>
</div>
